from django.shortcuts import render
from scraping.models import Job

# Create your views here.

def jobs(request):
    title = Job.objects.all()
    return render(request, 'show.html', {"Job":title})