from django.contrib import admin

# Register your models here.
from scraping.models import Job
admin.site.register(Job)