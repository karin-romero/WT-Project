from django.contrib import admin
from scraping.models import Job
admin.site.register(Job)


# Register your models here.
