from django.shortcuts import render


# Create your views here.

def index(request):
    return render(request, 'scraping/dashboard.html')

def tables(request):
    return render(request, 'scraping/tables.html')

def flot(request):
    return render(request, 'scraping/flot.html')

def morris(request):
    return render(request, 'scraping/morris.html')

def forms(request):
    return render(request, 'scraping/forms.html')

def panels_wells(request):
    return render(request, 'scraping/panels_wells.html')

def buttons(request):
    return render(request, 'scraping/buttons.html')

def notifications(request):
    return render(request, 'scraping/notifications.html')

def typography(request):
    return render(request, 'scraping/typography.html')

def icons(request):
    return render(request, 'scraping/icons.html') 

def grid(request):
    return render(request, 'scraping/grid.html')   

def blank(request):
    return render(request, 'scraping/blank.html')

def login(request):
    return render(request, 'scraping/login.html')                     
